How to Assemble the Assembly?
- Follow pic 1 ~ 12

What else do I need to follow?
- Step 1~2: There is no predrilled hole for the screw, please force the screw into the Encoder whell
- Step 3~4: Screw size is M3, no screw nut is required to hold the interrupter securily
- Step 5~6: 
- Step 7~8: The feet of Optical Interrupter Assembly might require some trimming in order to fit into Servo Mount (Error introduced by FDM printer)
- Step 9~10: Please note the gap between blinds rod and the adapter, this is recommended for easier installation and operation  
